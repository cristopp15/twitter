'use strict'

var moongose = require('mongoose');
var Schema = moongose.Schema;

var retweetSchema = Schema({
                    _id: String,
                    name: String,
                    username: String,
                    tweet: String,
                    noLikes: Number,
                    noAnswers: Number,
                    noRetweets: Number
        
});

module.exports = moongose.model('retweet', retweetSchema);