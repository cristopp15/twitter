'use strict'

var moongose = require('mongoose');
var Schema = moongose.Schema;

var userSchema = Schema({
    name: String,
    email: String,
    username: String,
    password: String,

    tweets: [{ 
                _id:String,
                tweet: String,
                noLikes: Number,
                noAnswers: Number,
                noRetweets: Number,
                likes:[{
                    _id: String,
                    username: String
                }],
                answers:[{
                    _id: String,
                    username: String
                }],
                retweets:[{
                    _id: String,
                    username: String
                }]
            }],
    retweets: [{tweet: String,
                 noLikes: Number, 
                 noAnswers: Number, 
                 noRetweets: Number, 
                 original:[{
                    _id: String,
                    name: String,
                    username: String,
                    tweet: String,
                    noLikes: Number,
                    noAnswers: Number,
                    noRetweets: Number
        }],
                likes:[{
                    _id: String,
                    username: String
                }],
                answers:[{
                    _id: String,
                    username: String
                }],
                retweets:[{
                    _id: String,
                    username: String
                }]
}],
    followers: [{ 
                _id: String, name: String,
                 username: String
                }],
    follow: [{ 
        _id: String, 
        name: String, 
        username: String
    }]
    
});

module.exports = moongose.model('user', userSchema);