'use strict'

var moongose = require('mongoose');
var Schema = moongose.Schema;

var tweetSchema = Schema({
    tweet: String,
    noLikes: Number,
    noAnswers: String,
    noRetweets: Number,
    likes:[{
        _id: String,
        username: String
    }],
    answers:[{
        _id: String,
        username: String
    }],
    retweets:[{
        _id: String,
        username: String
    }]
});

module.exports = moongose.model('tweet', tweetSchema);