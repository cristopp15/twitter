'use strict'

var User = require('../models/user.model');
var Tweet = require('../models/tweet.model');
var Follow = require('../models/follower.model');
var Retweet = require('../models/retweet.model');
var bcrypt = require('bcrypt-nodejs');
var jwt = require('../services/jwt');
const {decode} = require('jwt-simple');
const { update } = require('../models/user.model');



function commands(req, res){
    var us = new User();
    var params = req.body;
    var sp = params.command.split(" ");

    if(sp[0].toUpperCase() == 'REGISTER'){
        if(sp.length != 5){
            res.send({message: 'Ingrese los datos necesarios, SINTAXIS: REGISTER name email username password'});
        }else{
            User.findOne({$or:[{email: sp[2]}, {username: sp[3]}]}, (err, userFind) =>{
                if(err){
                    res.status(500).send({message: 'Error general', err});
                }else if(userFind){
                    res.send({message: 'El usuario o el correo ya está en uso'});
                }else{
                    us.name = sp[1];
                    us.email = sp[2];
                    us.username = sp[3];
                    
                    bcrypt.hash(sp[4], null, null, (err, passwordHash)=>{
                        if(err){
                            res.status(500).send({message: 'Error', err});
                        }else if(passwordHash){
                            us.password = passwordHash;

                            us.save((err, userSaved)=>{
                                if(err){
                                    res.status(500).send({message: 'Error general', err});
                                }else if(userSaved){
                                    res.send({message: 'Usuario registrado', user: userSaved});
                                }else{
                                    res.status(404).send({message: 'Error al registrar usuario'});
                                }
                            });
                        }else{
                            res.status(410).send({message: 'Error inesperado'});
                        }
                    })
                }
            })
       
            
        }

    }else if(sp[0].toUpperCase() == 'LOGIN'){
        if(sp.length == 3){
            User.findOne({$or:[{email: sp[1]}, {username: sp[1]}]}, (err, user)=>{
                if(err){
                    res.status(500).send({message: 'Error general', err});
                }else if(user){
                    bcrypt.compare(sp[2], user.password, (err, passworOk)=>{
                        if(err){
                            res.status(500).send({message: 'Error', err})
                        }else if(passworOk){
                            if(params.gettoken = 'true'){
                                res.send({token: jwt.createToken(user)});
                            }else{
                                res.send({message: 'Error al generar TOKEN'});
                            }
                        }else{
                            res.send({message: 'Contraseña incorrecta'})
                        }
                    })
                }else{
                    res.send({message: 'Datos de inicio de sesión incorrectos, SINTAXIS: LOGIN (email||username) password'})
                }
            })
        }else{
            res.send({message: 'Error al iniciar sesión, SINTAXIS: LOGIN (email||username) password'});
        }

    }else if(sp[0].toUpperCase() == 'ADD_TWEET'){
        if(sp.length >= 2){
            var userId = req.user.sub;
            var tweet = new Tweet();
            var twee = "";

            for(var i = 1; i < sp.length; i++){
                var twee = twee + sp[i] + " "; 
            }

            tweet.tweet = twee;

            User.findByIdAndUpdate(userId, {$push:{tweets: tweet}}, {new: true}, (err, tweetAdded)=>{
                if(err){
                    res.status(500).send({message: 'Error general', err});
                }else if(tweetAdded){
                    res.send({message: 'El tweet se publicó correctamente', User: tweetAdded.name, Tweets: tweetAdded.tweets});
                }else{
                    res.status(404).send({message: 'Error',err});
                }
            })
        }else{
            res.send({message: 'Datos insuficientes, SINTAXIS: ADD_TWEET tweet'})
        }

    }else if(sp[0].toUpperCase() == 'DELETE_TWEET'){
        if(sp.length == 2){
            var userId = req.user.sub;
            var tweetId = sp[1];

            User.findOneAndUpdate({_id: userId, "tweets._id": tweetId}, {$pull:{tweets:{_id: tweetId}}}, {new: true}, (err, tweetdeleted)=>{
                if(err){
                    res.status(500).send({message: 'Error general', err});
                }else if(tweetdeleted){
                    res.send({message: 'Tweet eliminado', User: tweetdeleted.name, Tweets: tweetdeleted.tweets});
                }else{
                    res.status(418).send({message: 'ERROR'});
                }
            })
        }else{
            res.send({message: 'Error al eliminar tweet, SINTAXIS: DELETE_TWEET idTweet'})
        }

    }else if(sp[0].toUpperCase() == 'EDIT_TWEET'){
        if(sp.length >= 3){
            var userId = req.user.sub;
            var tweetId = sp[1];
            var twee = "";

            for(let i = 2; i < sp.length; i++){
                twee = twee + sp[i] + " ";
            }

            User.findOne({_id: userId}, (err, userOk)=>{
                if(err){
                    res.status(500).send({message: 'Error general', err});
                }else if(userOk){
                    User.findOneAndUpdate({_id: userId, "tweets._id": tweetId}, {"tweets.$.tweet": twee}, {new: true}, (err, tweetUpdated)=>{
                        if(err){
                            res.status(500).send({message: 'Error general', err});
                        }else if(tweetUpdated){
                            res.send({message: 'Tweet editado correctamente', User: tweetUpdated.name, Tweets: tweetUpdated.tweets});
                        }else{
                            res.status(418).send({message: 'ERROR'});
                        }
                    })
                }else{
                    res.status(404).send({message: 'ERROR 2'});
                }
            })
        }else{
            res.send({message: 'Error al editar tweet, SINTAXIS: EDIT_TWEET idTweet textoDelTweet'})
        }
    
    // }else if(sp[0].toUpperCase() == 'VIEW_TWEETS'){
    //     if(sp.length == 2){
            
    //         User.findOne({username: sp[1]}, (err, userK)=>{
    //             if(err){
    //                 res.status(500).send({message: 'Error general', err});
    //             }else if(userK){
    //                 res.send({message: 'INFO TWEETS', User: userK.name, Username: userK.username, Tweets: userK.tweets});
    //             }else{
    //                 res.status(404).send({message: 'ERROR'});
    //             }
    //         })
    //     }else{
    //         res.send({message: 'Error al mostrar tweets, SINTAXIS: VIEW_TWEETS username'})
    //     }

    }else if(sp[0].toUpperCase() == 'FOLLOW'){
        if(sp.length == 2){
            var follower = new Follow();
            var user = req.user;

            if(user.username == sp[1]){
                res.send({message: 'Eres tu mismo, no puedes seguirte'});
            }else{
                follower._id = user.sub;
                follower.name = user.name;
                follower.username = user.username;

                User.findOneAndUpdate({username: sp[1], "followers._id": user.sub}, null, {new: true}, (err, userOk)=>{
                    if(err){
                        res.send({message: 'Error general', err});
                    }else if(userOk){
                        res.send({message: 'Ya sigues a este usuario'});
                    }else{
                        User.findOneAndUpdate({username: sp[1]}, {$push:{followers: follower}}, {new: true}, (err, followerOk)=>{
                            if(err){
                                res.status(500).send({message: 'Error general', err});
                            }else if(followerOk){
                                follower._id = followerOk._id;
                                follower.name = followerOk.name;
                                follower.username = followerOk.username;

                                User.findOneAndUpdate({_id: user.sub}, {$push:{follow: follower}}, {new: true}, (err, followOk)=>{
                                    if(err){
                                        res.status(500).send({message: 'Error general', err});
                                    }else if(followOk){
                                        res.send({message: 'COMENZASTE A SEGUIR AL USUARIO', User: followOk.name, Username: followOk.username, Follow: followOk.follow});
                                    }else{
                                        res.send({message: 'Error'});
                                    }
                                })
                            }else{
                                res.send({message: 'Usuario NO EXISTE'});
                            }
                        })
                    }
                })
            }
        }else{
            res.send({message: 'Error al seguir usuario, SINTAXIS: FOLLOW username'})
        }
    }

    else if(sp[0].toUpperCase() == 'UNFOLLOW'){
        if(sp.length == 2){
            var user = req.user;

            if(user.username == sp[1]){
                res.send({message: 'Es imposible realizar esta acción'});
            }else{

                User.findOneAndUpdate({_id: user.sub, "follow.username": sp[1]}, {$pull:{follow:{username: sp[1]}}}, {new: true}, (err, userOk)=>{
                    if(err){
                        res.send({message: 'Error general', err});
                    }else if(userOk){
                        User.findOneAndUpdate({username: sp[1], "followers._id": user.sub}, {$pull:{followers:{_id: user.sub}}}, {new: true}, (err, userdelete)=>{
                            if(err){
                                res.status(500).send({message: 'Error general', err});
                            }else if(userdelete){
                                res.send({message: 'Lo dejaste de seguir', User: userOk.name, Username: userOk.username, Follow: userOk.follow});
                            }else{
                                res.send({message: 'Error'})
                            }
                        })
                    }else{
                        res.send({message: 'No existe o no lo sigues'});
                    }
                })
            } 
        }else{
            res.send({message: 'Error al dejar de seguir usuario, SINTAXIS: UNFOLLOW username'})
        }
    }

    else if(sp[0].toUpperCase() == 'PROFILE'){
        if(sp.length == 2){
            var user = req.user;        

            User.findOne({username: sp[1]}, (err, userOk)=>{
                if(err){
                    res.status(500).send({message: 'Error general', err});
                }else if(userOk){
                    if(userOk.username == user.username){
                        res.send({message: 'PERFIL:', Name: userOk.name,
                                                                Username: userOk.username,
                                                                Email: userOk.email,
                                                                Password: userOk.password,
                                                                Tweets: userOk.tweets,
                                                                Follow: userOk.follow,
                                                                Followers: userOk.followers});
                    }else{
                        res.send({message: 'ERROR, NO ES SU PERFIL '})
                    }
                }else{
                    res.send({message: 'Perfil no encontrado'})
                }
            })
        
        }else{
            res.send({message: 'Error , SINTAXIS: PROFILE username'})
        }
    }else if(sp[0].toUpperCase() == "LIKE_TWEET"){
        if(sp.length == 2){
            var user = req.user;
            var follower = new Follow();
            
            User.findOne({$or:[{"tweets._id": sp[1], "followers.username": user.username}, {"retweets._id": sp[1], "followers.username": user.username}]}, (err, tweetOk) => {
                if(err){
                    res.status(500).send({message: 'Error general'});
                }else if(tweetOk){
                    var arr;
                    var twee = tweetOk.tweets;
                    var tC = tweetOk.retweets;
                    var con = 0;
                    var update;

                    twee.forEach(twI => {
                        if(twI._id == sp[1]){
                            arr = tweetOk.tweets
                            if(twI.noLikes == null){
                                twI.noLikes = 0;
                            }
                            update = {$push:{"tweets.$[twI].likes": follower}, "tweets.$[twI].noLikes": (twI.noLikes + 1)};
                        }
                    });

                    tC.forEach(tC => {
                        if(tC._id == sp[1]){
                            arr = tweetOk.retweets;
                            if(tC.noLikes == null){
                                tC.noLikes = 0;
                            }
                            update = {$push:{"retweets.$[twI].likes": follower}, "retweets.$[twI].noLikes": (tC.noLikes + 1)};
                        }
                    });
                    
                    arr.forEach(tweet => {
                        var arr2 = tweet.likes;

                        arr2.forEach(like => {
                            if(tweet._id == sp[1] && like._id == req.user.sub){
                                con = 2;
                            }
                        });
                    });

                    if(con == 0){
                        follower._id = req.user.sub;
                            follower.username = req.user.username;

                            User.findByIdAndUpdate(tweetOk._id, update, {arrayFilters:[{"twI._id": sp[1]}], new: true}, (err, liked)=>{
                                if(err){
                                    res.status(500).send({message: 'Error general', err});
                                }else if(liked){
                                    res.send({message: 'Le diste like al tweet', username: liked.username, like: liked.tweets, retweets: liked.retweets});
                                }else{
                                    res.send({message: 'Error al darle like al tweet'});
                                }
                            })
                        
                    }else if(con != 0){
                        res.send({message: 'Ya le diste like al tweet'});
                    }
                }else{
                    res.send({message: 'ERROR 1'});
                }
            });
        }else{
            res.send({message: 'Error 2, SINTAXIS LIKE_TWEET idTweet'});
        }

       }else if(sp[0].toUpperCase() == "DISLIKE_TWEET"){
        if(sp.length == 2){
            User.findOne({$or:[{"tweets._id": sp[1], "followers.username": req.user.username}, {"retweets._id": sp[1], "followers.username": req.user.username}]}, (err, tweetOk) => {
                if(err){
                    res.status(500).send({message: 'Error general'});
                }else if(tweetOk){
                    var arr;
                    var twee = tweetOk.tweets;
                    var tC = tweetOk.retweets;
                    var con = 0;
                    var update;

                    twee.forEach(twI => {
                        if(twI._id == sp[1]){
                            arr = tweetOk.tweets
                            if(twI.noLikes == null){
                                twI.noLikes = 1;
                            }
                            update = {$pull:{"tweets.$[twI].likes": {username: req.user.username}}, "tweets.$[twI].noLikes": (twI.noLikes - 1)};
                        }
                    });

                    tC.forEach(tC => {
                        if(tC._id == sp[1]){
                            arr = tweetOk.retweets;
                            if(tC.noLikes == null){
                                tC.noLikes = 1;
                            }
                            update = {$pull:{"retweets.$[twI].likes": {user: req.user.username}}, "retweets.$[twI].noLikes": (tC.noLikes - 1)};
                        }
                    });
                    
                    arr.forEach(tweet => {
                        var arr2 = tweet.likes;

                        arr2.forEach(like => {
                            if(tweet._id == sp[1] && like._id == req.user.sub){
                                con = 1;
                            }
                        });
                    });

                    if(con == 1){
                            User.findByIdAndUpdate(tweetOk._id, update, {arrayFilters:[{"twI._id": sp[1]}], new: true}, (err, disliked)=>{
                                if(err){
                                    res.status(500).send({message: 'Error general', err});
                                }else if(disliked){
                                    res.send({message: 'Se quito el like al tweet', username: disliked.username, like: disliked.tweets, retweets: disliked.retweets});
                                }else{
                                    res.send({message: 'Error al quitar el like al tweet'});
                                }
                            })
                        
                    }else if(con == 0){
                        res.send({message: 'No le has dado like al tweet'});
                    }
                }else{
                    res.send({message: 'ERROR 1'});
                }
            });
        }else{
            res.send({message: 'Error 2, SINTAXIS DISLIKE_TWEET idTweet'});
        }

       }else if (sp[0].toUpperCase() == "REPLY_TWEET"){
        if(sp.length >= 3){
            let tweeti = new Tweet();
            let twit = "";
 
            for(let i = 2; i < sp.length; i++){
                twit = twit + sp[i] + " ";
            }

            User.findOne({$or:[{"tweets._id": sp[1], "followers.username": req.user.username}, {"retweets._id": sp[1], "followers.username": req.user.username}]}, (err, twitOk) => {
                if(err){
                    res.send({message: 'Error general', err});
                }else if(twitOk){
                    var update;
                    var tws = twitOk.tweets;
                    var shared = twitOk.retweets;
                    var ac = 0;
                    
                    tweeti.username = req.user.username;
                    tweeti.tweet = twit;

                    tws.forEach(tw => {
                        if(tw._id == sp[1]){
                            if(tw.noAnswers == null){
                                tw.noAnswers = 0;
                            }
                            update = {$push:{"tweets.$[tw].answers": tweeti}, "tweets.$[tw].noAnswers": (tw.noAnswers + 1)};
                        }
                    });

                    shared.forEach(shared => {
                        if(shared._id == sp[1]){
                            ac = 3;
                            update = {$push:{"shared.$[tw].answers": tweeti}, "shared.$[tw].noAnswers": (shared.noAnswers + 1)};
                        }
                    });
                    
                    User.findByIdAndUpdate(twitOk._id, update, {arrayFilters:[{"tw._id": sp[1]}], new: true}, (err, answerOk) =>{
                        if(err){
                            res.status(500).send({message: 'Error general', err});
                        }else if(answerOk){
                            if(ac == 0){
                                let tweets = answerOk.tweets;
                                tweets.forEach(tw => {
                                    if(tw._id == sp[1]){
                                        res.send({message: 'Respuesta Exitosa',
                                                    Name: answerOk.name,
                                                    Username: answerOk.username,
                                                    Id: tw._id,
                                                    Tweet: tw.tweet,
                                                    Likes: tw.likes.length,
                                                    Retweets: tw.retweets.length,
                                                    NoAnswers: tw.noAnswers,
                                                    Answers: tw.answers
                                                    })
                                    }
                                });
                            }else if(ac != 0){
                                let twiits = answerOk.twiits;
                                twiits.forEach(twC => {
                                    if(twC._id = sp[1]){
                                        res.send({message: 'Respuesta Exitosa',
                                                    Name: answerOk.name,
                                                    Username: answerOk.username,
                                                    Id: twC._id,
                                                    Answers: twC.answers,
                                                    "Tweet Original": twC.original,
                                                    Likes: twC.likes.length,
                                                    NoAnswers: twC.noAnswers,
                                                    Answers: twC.answers
                                                })
                                    }
                                });
                            }
                        }else{
                            res.send({message: 'Error desconocido, intente mas tarde'});
                        }
                    })

                }else{
                    res.send({message: 'Errores posibles: No existe el tweet / No sigues al usuario'});
                }
            })
            
        }else{
            res.send({message: "Error al responder tweet, SINTAXIS REPLY_TWEET idtweet textoDeRespuesta)"});
        }
    }else if(sp[0].toUpperCase() == "RETWEET"){
        if(sp.length >= 2){
            var rtw = new Retweet(); 
            var fw = new Follow();
            var t = "";

            for(let i = 2; i < sp.length; i++){
                t = t + sp[i] + " ";
            }

            fw._id = req.user.sub;
            fw.username = req.user.username; 

            User.findOne({"tweets._id": sp[1]}, (err, tweetO) =>{
                if(err){
                    res.send({message: 'Error general', err});
                }else if(tweetO){
                    
                    var rtws = tweetO.tweets;

                    User.findById(req.user.sub, (err, userOk) => {
                        if(err){
                            res.status(500).send({message: 'Error general', err});
                        }else if(userOk){
                            var retweets2 = userOk.retweets;
                            var cons = 0;
        
                            retweets2.forEach(twC => {
                                    var twsO = twC.tweetO;    
                                    
                                    twsO.forEach(tw2 => {
                                        if(tw2._id == sp[1]){
                                            cons = cons + 5;
                                        }
                                    });
                            });
        
                            if(cons != 0){
                                res.send({message: 'Tweet ya compartido'});
                            }else if(cons == 0){

                                rtws.forEach(tweet => {
                                    if(tweet._id == sp[1]){
                                        rtw._id = tweet._id;
                                        rtw.name = tweetO.name;
                                        rtw.username = tweetO.username;
                                        rtw.tweets = tweet.tweets;
                                        rtw.likes = tweet.likes.length;
                                        rtw.answers = tweet.answers.length;
            
                                        if(tweet.noRetweets == null){
                                            tweet.noRetweets = 0;
                                        }

                                        User.findOneAndUpdate({"tweets._id": sp[1]}, {$push:{"tweets.$[tw].retweets": fw}, "tweets.$[tw].noRetweets": (tweet.noRetweets + 1)}, {arrayFilters:[{"tw._id": sp[1]}], new: true}, (err, find) => {})
                                    }
                                });
        
                                User.findByIdAndUpdate(req.user.sub, {$push:{retweets:{tweet: t}}}, {new: true}, (err, retwit)=>{
                                    if(err){
                                        res.send({message: 'Error general', err}); 
                                    }else if(retwit){
                                        let index = retwit.retweets.length - 1;

                                        User.findByIdAndUpdate(req.user.sub, {$push:{"retweets.$[tw].original": rtw}}, {arrayFilters:[{"tw._id": retwit.retweets[index]._id}], new: true}, (err, retweetOk) =>{
                                            if(err){
                                                res.status(500).send({message: 'Error general', err});
                                            }else if(retweetOk){
                                                res.send({retweetOk});
                                            }else{
                                                res.send({message: 'Error al compartir tweet'});
                                            }
                                        })
                                    }else{
                                        res.send({message: 'Error al compartir tweet'});
                                    }
                                })
                            }
                        }else{
                            res.status(404).send({message: 'Usuario no encontrado'});
                        }
                    })
                }else{
                    res.status(404).send({message: 'Tweet no encontrado'});
                }
            })
        }else{
            res.send({message: 'Error SINTAXIS: RETWEET idTweet texto(opcional)'})
        }

    }else if(sp[0].toUpperCase() == 'VIEW_TWEETS'){
        if(sp.length == 2){

                
            User.findOne({username: sp[1]}, {"tweets.likes": 0, "tweets.answers": 0, "tweets.retweets": 0,
                                                  "retweets.likes": 0, "retweets.answers": 0, "retweets.retweets": 0},  (err, userOk)=>{
                if(err){
                    res.status(500).send({message: 'Error general', err});
                }else if(userOk){
                    res.send({username: userOk.username, Tweets: userOk.tweets, Retweets: userOk.retweets});
                }else{
                    res.status(404).send({message: 'Usuario no encontrado'});
                }
            }) 
        }else{
            res.send({message: 'Error al mostrar tweets, SINTAXIS: VIEW_TWEETS username)'})
        }
    }else{
        res.send({message:"El comando no se reconoce"});
    }
}



module.exports = {
    commands
}